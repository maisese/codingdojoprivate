
public class NinjaTest {

	public static void main(String[] args) {
		Ninja ninja1 = new Ninja();
		Ninja ninja2 = new Ninja();
		
		ninja1.steal(ninja2);
		ninja1.runAway();
		
	}

}
