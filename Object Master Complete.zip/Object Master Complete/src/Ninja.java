
public class Ninja extends Human{
	
	private int stealth;

	public Ninja() {
		this.stealth = 10;
	}
	
		
	public Ninja(int stealth) {
		this.stealth = stealth;
	}


	public int getStealth() {
		return stealth;
	}


	public void setStealth(int stealth) {
		this.stealth = stealth;
	}


	//The Ninja class should have a default stealth of 10; 
	//a method, steal, that takes health from another human by their stealth level, and 
	//a way to run away that decreases their health by 10.
	//Put HUMAN is the type, as other players are instances of Human
	
	public void steal(Human otherplayer) {
		int stealhealth = otherplayer.getHealth() - getStealth();
		otherplayer.setHealth(stealhealth);
		System.out.println("Your ninja stole. Other player's health is: " + otherplayer.getHealth());
	}
	
	public void runAway() {
		int healthafterrunning = getHealth() - 10; 
		setHealth(healthafterrunning);
		System.out.println("Your ninja ran away! Coward!  Your health is now: " + getHealth());
	}

}
