
public class WizardTest {

	public static void main(String[] args) {
		Wizard player1 = new Wizard();
		Wizard player2 = new Wizard();
		
		player1.heal(player2);
		player1.fireball(player2);

	}

}
