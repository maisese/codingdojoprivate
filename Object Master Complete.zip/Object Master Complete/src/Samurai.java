
public class Samurai extends Human{
	
	private static int counter;
	private int health;
	
	public Samurai() {
		this.health = 200;
		counter++;
	}
	
	
	public Samurai(int health) {
		super();
		this.health = health;
	}
	
	//Getters and Setters
	public static int getCounter() {
		return counter;
	}


	public static void setCounter(int counter) {
		Samurai.counter = counter;
	}


	public int getHealth() {
		return health;
	}


	public void setHealth(int health) {
		this.health = health;
	}

	//Methods
	//a method called deathBlow that attacks an object and decreases its health to 0, but also halves the Samurai's health; a method called meditate which heals the Samurai back to full health; and a method called howMany that returns the current number of Samurai.
	
	public void deathBlow(Human otherplayer) {
		otherplayer.setHealth(0);
		int personaldamange = getHealth()/2;
		setHealth(personaldamange);
		System.out.println("Samuri just delivered the death blow.  Other player's health is now " + otherplayer.getHealth() + ", and your Samuri's health is now " + getHealth());
		
		}
	
	public void meditate() {
		setHealth(200);
		System.out.println("Samauri medidated and is fully recoverd.  Health is now " + getHealth());
	}
	
	public static int howMany() {
		System.out.println("There are this many Samurai: " + getCounter());
		return getCounter();
	}
		
		

}


