
public class Human {
	private int strength = 3; 
	private int stealth = 3;
	private int intelligence =3;
	private int health = 100;
	
	public Human() {
		
	}
	
	public Human(int strength, int stealth, int intelligence, int health) {
		this.strength = strength;
		this.stealth = stealth;
		this.intelligence = intelligence;
		this.health = health;
	}
	
	public int getStrength() {
		return strength;
	}

	public void setStrength(int strength) {
		this.strength = strength;
	}

	public int getStealth() {
		return stealth;
	}

	public void setStealth(int stealth) {
		this.stealth = stealth;
	}

	public int getIntelligence() {
		return intelligence;
	}

	public void setIntelligence(int intelligence) {
		this.intelligence = intelligence;
	}

	public int getHealth() {
		return health;
	}

	public void setHealth(int health) {
		this.health = health;
	}
	
	public void displayEnergy() {
        System.out.println("Th health level is: " + getHealth());
	}
	
	//Each human should also have the ability to attack, where they decrease the health of whatever they attacked by their strength.
	public int attack(Human otherplayer) {
		int otherplayerdamage = otherplayer.getHealth() - this.getStrength();
		otherplayer.setHealth(otherplayerdamage);
		System.out.println("You attacked someone! That someone's health is " + otherplayer.getHealth());
		return otherplayer.getHealth();
	} 
	
	
	
	
	
}
