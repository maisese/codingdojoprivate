
public class Wizard extends Human{
	//Variables
	private int health;
	private int intelligence;
	
	//Java Beans - empty constructor (make yourself)
	public Wizard(){
		this.health = 50;
		this.intelligence = 8;
	}
	
	//Java Beans - constructor (made via src new constructor)
	public Wizard(int health, int intelligence) {
		this.health = health;
		this.intelligence = intelligence;
	}
	
	//JavaBeans - getters and setters (made via src getters/setters)
	public int getHealth() {
		return health;
	}

	public void setHealth(int health) {
		this.health = health;
	}

	public int getIntelligence() {
		return intelligence;
	}

	public void setIntelligence(int intelligence) {
		this.intelligence = intelligence;
	}
	
	//Methods here
	//a method called heal that heals whomever it was cast on for an amount equal to the wizard's intelligence; and a 	//method called fireball that decreases the health of whichever object it attacked by 3 * the wizard's intelligence.
	//Put HUMAN is the type, as other players are instances of Human

	public void heal(Human otherplayer) {
		System.out.println("Other Wiz needs to be healed. Their current health is " + otherplayer.getHealth());
		int healthimprovement = otherplayer.getHealth() + getIntelligence();
		otherplayer.setHealth(healthimprovement);
		System.out.println("Other recieved healing and has a new health of " + otherplayer.getHealth());
	}
	
	public void fireball(Human otherplayer) {
		System.out.println("Time to throw a fireball, the other player's current health is " + otherplayer.getHealth());
		int damage = otherplayer.getHealth() - (getIntelligence()*3);
		otherplayer.setHealth(damage);
		System.out.println("Take that other player! Other player's health is  " + otherplayer.getHealth());
	}
	
}
