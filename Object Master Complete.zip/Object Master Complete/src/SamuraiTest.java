
public class SamuraiTest {

	public static void main(String[] args) {
	Samurai player1 = new Samurai();
	Samurai player2 = new Samurai();
	
	player1.deathBlow(player2);
	player1.meditate();
	Samurai.howMany();

	}

}
