import java.util.Arrays;
public class Basic13Main {
    public static void main(String[] args) {
        Basic13 bubbles = new Basic13();
        // bubbles.printTo255();
        // bubbles.printOddsto255();
        // bubbles.printIntsandSum();

        // // ===4
        // Integer arr[] = { 1, 2, 4 };
        // bubbles.iterateandPrintArray(arr);

        // // 5
        // Integer arr[] = { 1, 2, 4 };
        // bubbles.findMax(arr);

        // // 6
        // int[] arr = { 1, 2, 3, 4 };
        // bubbles.getPrintAVG(arr);

        // // 7
        // bubbles.printOdds();

        // // 8
        // int[] arr = { 1, 2, 3, 4 };
        // bubbles.printSQR(arr);

        // // 9
        // int[] arr = { 1, 2, 3, 4 };
        // bubbles.greatThanY(arr, 2);

        // // 10
        // int[] arr = { -1, 2, 3, -4 };
        // bubbles.ZeroOutNegs(arr);
        // System.out.println(Arrays.toString(arr));

        // // 11
        // int[] arr = { 10, 2, 3, 5 };
        // bubbles.maxMinAverage(arr);

        //12
        int[] arr = { 10, 2, 3, 5 };
        bubbles.shiftArrayVales(arr);
        System.out.println(Arrays.toString(arr));

        //13 
        // int[] arr = { -10,-2, 3, 5 };
        // String [] strArr=bubbles.swapStringForArrayNegs(arr);
        // System.out.println(Arrays.toString(strArr));


        
    }
}