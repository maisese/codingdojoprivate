package com.ms.dojosandninjas.services;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ms.dojosandninjas.models.Dojo;
import com.ms.dojosandninjas.models.Ninja;
import com.ms.dojosandninjas.repositories.NinjaRepository;

@Service
public class NinjaService {

	@Autowired 
	public NinjaRepository ninjaRepo;

	public void createNewNinja(@Valid Ninja nin) {
		ninjaRepo.save(nin);
	}
	

	
	
}
