package com.ms.dojosandninjas.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ms.dojosandninjas.models.Dojo;
import com.ms.dojosandninjas.models.Ninja;
import com.ms.dojosandninjas.repositories.DojoRepository;

@Service
public class DojoService {
	@Autowired 
	public DojoRepository dojoRepo;

	public void createNewDojo(Dojo d) {
		dojoRepo.save(d);
	}

	public List<Dojo> getAllDojos() {
		return dojoRepo.findAll();
	}


	public Dojo getDojo(Long id) {
		Optional <Dojo> getdojoInfo = dojoRepo.findById(id);
		if (getdojoInfo.isPresent()) {
		Dojo dojoInfo =  getdojoInfo.get();
		return dojoInfo;
		}
		else {
			return null;
		}
	}
	
}


