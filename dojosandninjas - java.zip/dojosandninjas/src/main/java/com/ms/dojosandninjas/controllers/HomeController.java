package com.ms.dojosandninjas.controllers;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.ms.dojosandninjas.models.Dojo;
import com.ms.dojosandninjas.models.Ninja;
import com.ms.dojosandninjas.services.DojoService;
import com.ms.dojosandninjas.services.NinjaService;

@Controller
public class HomeController {
	@Autowired
	public DojoService dojoServ;
	
	@Autowired
	public NinjaService ninjaServ;
	
	@GetMapping("/")
	public String homeRoute() {
		return "index.jsp";
	}
	
	@GetMapping("/dojos/new")
	//@ModelAttribute - it is expecting to create a new instance, called DojoObj, modeling Dojo dojo, dojo stores the new bean (instance) 
	public String newdojo(@ModelAttribute("dojoObj") Dojo dojo) {
		return "dojos/new.jsp";
	}
	
	@PostMapping("/newDojo")
	//dojo creates the instance, and result is what is stored
		public String createDojo(@Valid @ModelAttribute("dojoObj") Dojo dojo, BindingResult results) {
		if (results.hasErrors()) {
			return "dojos/new.jsp";
		}
		else {
			dojoServ.createNewDojo(dojo);
			return "redirect:/ninjas/new";
		}
	}
	
	@GetMapping("/ninjas/new")
	public String newNinja(Model model, @ModelAttribute("ninjaObj") Ninja ninja) {
		List <Dojo> allDojos = dojoServ.getAllDojos();
		model.addAttribute("dojos", allDojos);
		return "ninjas/new.jsp";
	}
	
	@PostMapping("/newNinja")
	//dojo creates the instance, and result is what is stored
		public String createNinja(Model model, @Valid @ModelAttribute("ninjaObj") Ninja ninja, BindingResult results) {
		if (results.hasErrors()) {
			List <Dojo> allDojos = dojoServ.getAllDojos();
			model.addAttribute("dojos", allDojos);	
			return "ninjas/new.jsp";
		}
		else {
			ninjaServ.createNewNinja(ninja);
			System.out.println("this is the new ninja" + ninja);
			Long id = ninja.getDojo().getId();
			return "redirect:/dojos/"+ id;
		}
	}
	
	
	
	@GetMapping("/dojos/{id}")
	public String dojosAndNinjas(@PathVariable("id") Long id, Model model) {
		Dojo dojo = dojoServ.getDojo(id);
		model.addAttribute("dojosNinjas", dojo);
		return "dojos/show.jsp";
	}
	
	/*
	 * @GetMapping("/dojos/{id}") public String dojosAndNinjas2(@PathVariable("id")
	 * Long id, Model model) { Dojo dojo = dojoServ.getDojo(id);
	 * model.addAttribute("dojosNinjas", dojo); List<Ninja> ninja =
	 * dojo.getNinjas(); model.addAttribute("ninja", ninja); return
	 * "dojos/show.jsp"; }
	 */
	
}
