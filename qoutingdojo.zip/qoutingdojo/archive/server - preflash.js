var express = require('express');
var app = express();
var bodyParser = require('body-parser');
var mongoose = require('mongoose');
var session = require('express-session');
app.use(bodyParser.urlencoded({ extended: true }));
var path = require('path');

// This is how we connect to the mongodb database using mongoose -- "basic_mongoose" is the name of
//   our db in mongodb -- this should match the name of the db you are going to use for your project.
mongoose.connect('mongodb://localhost/quote2');
let QuoteSchema = new mongoose.Schema({
    author:  { type: String, required: true, minlength: 2},
    quote: { type: String, required: true, minlength: 2 },
    }, {timestamps: true });
   var Quote = mongoose.model('Quote', QuoteSchema); 



// Setting our Static Folder Directory
app.use(express.static(path.join(__dirname, './static')));
// Setting our Views Folder Directory
app.set('views', path.join(__dirname, './views'));
// Setting our View Engine set to EJS
app.set('view engine', 'ejs');
// Routes
// Root Request

app.get('/', function(req, res) {
    // This is where we will retrieve the users from the database and include them in the view page we will be rendering.
    res.render('index');
});

app.post('/newqoute', function(req, res) {
    console.log("putting things in your database");
    var quote = new Quote({author: req.body.author, quote: req.body.quote});
    quote.save(function (err){
        //error validation
    });
    console.log("POST DATA", req.body);
    // This is where we would add the user from req.body to the database.
    res.redirect('/quotes');
});

app.get('/quotes', function(req, res) {
    Quote.find({}, function(err, quotes){ //quotes is scopped to this callback function, and the data being retrieved fromm the database. 
        //error messenging
        res.render('quotes', {quotes: quotes});
    });
    
});   


app.listen(8000, function() {
    console.log("listening on port 8000");
});