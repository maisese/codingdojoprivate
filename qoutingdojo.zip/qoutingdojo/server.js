var express = require('express');
var app = express();
var bodyParser = require('body-parser');
var mongoose = require('mongoose');
var session = require('express-session');

app.use(bodyParser.urlencoded({ extended: true }));
var path = require('path');

var flash = require('express-flash');
app.use(flash());

app.use(session({ cookie: { maxAge: 60000 }, 
    secret: 'woot',
    resave: false, 
    saveUninitialized: false}));

// This is how we connect to the mongodb database using mongoose -- "basic_mongoose" is the name of
//   our db in mongodb -- this should match the name of the db you are going to use for your project.
mongoose.connect('mongodb://localhost/quote2');
let QuoteSchema = new mongoose.Schema({
    author:  { type: String, required: true, minlength: 2},
    quote: { type: String, required: true, minlength: 2 },
    }, {timestamps: true });
   var Quote = mongoose.model('Quote', QuoteSchema); 



// Setting our Static Folder Directory
app.use(express.static(path.join(__dirname, './static')));
// Setting our Views Folder Directory
app.set('views', path.join(__dirname, './views'));
// Setting our View Engine set to EJS
app.set('view engine', 'ejs');
// Routes
// Root Request

app.get('/', function(req, res) {
    // This is where we will retrieve the users from the database and include them in the view page we will be rendering.
    res.render('index');
});



app.post('/newqoute', function(req, res) {
    console.log("putting things in your database");
    var quote = new Quote({author: req.body.author, quote: req.body.quote});
    quote.save(function (err){
        if(err){
            // if there is an error upon saving, use console.log to see what is in the err object 
            console.log("We have an error!", err);
            // adjust the code below as needed to create a flash message with the tag and content you would like
            for(var key in err.errors){
                req.flash('author', err.errors[key].message);
            }
            // redirect the user to an appropriate route
            res.redirect('/');
        }
        else {
            res.redirect('/quotes');
        }
    });
});

app.get('/quotes', function(req, res) {
    Quote.find({}).sort({createdAt: 'desc'}).exec(function(err, quotes){ //quotes is scopped to this callback function, and the data being retrieved from the database. 
        //error messenging
        res.render('quotes', {quotes: quotes});
    });
    
});   


app.listen(8000, function() {
    console.log("listening on port 8000");
});