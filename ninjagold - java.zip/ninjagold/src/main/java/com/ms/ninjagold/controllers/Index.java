package com.ms.ninjagold.controllers;


import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Random;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class Index {
	
	ArrayList <String> messagelog = new ArrayList<String>();
	
	@RequestMapping("/") 
	public String index(Model model) {
        model.addAttribute("messagelog", messagelog);
		return "index.jsp";
        }
	
	@RequestMapping("/{param}")
	public String doSomething(@PathVariable("param") String param, HttpSession session ){
		
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("EEE,  MMMM d, yyyy'  at  ' hh:mm a");
		LocalDateTime now = LocalDateTime.now();
//		System.out.println(dtf.format(now)); //2016/11/16 12:08:43
//		DateTimeFormatter entry =  DateTimeFormatter.ofLocalizedDateTime(FormatStyle.MEDIUM);
		
		System.out.println(param);
		
		int goldresult;
		
		Random rg = new Random();
		
		
		if (param.equals("farm")) {
			goldresult = rg.nextInt(20-10)+10;
			System.out.println(goldresult);
		}
		else if (param.equals("cave")) {
			goldresult = rg.nextInt(10-5)+5;
			System.out.println(goldresult);
		}
		else if (param.equals("house")) {
			goldresult = rg.nextInt(20-10)+10;
			System.out.println(goldresult);
		}
		else {
			goldresult = rg.nextInt(100)-50;
			System.out.println(goldresult);
		}

		Integer gc = (Integer) session.getAttribute("goldcounter");
		if (gc == null) {
			System.out.println("it is not here" + gc);
			session.setAttribute("goldcounter", goldresult);
		}
		else {
			session.setAttribute("goldcounter", (gc+goldresult));
		}
		String message = "You entered a " + param +" and earned " + goldresult + " gold pieces. " + dtf.format(now);
		session.setAttribute("message", message);
		
		messagelog.add(message);
		System.out.println("this is my messagelog" + messagelog);
		
		return "redirect:/";
//		return "index.jsp";

	}
}
      

	
