package com.codingodojo.familiarrouting;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController

public class DojoController {
	@RequestMapping("/{param}")
	public String showLesson(@PathVariable("param") String param){
		if (param.equals("dojo")) {
			return "The " + param + " is awesome.";
		}
		else if (param.equals("berkeley-dojo")) {
			return "The Berkeley Dojo is located in Emeryville.";
		}
		else if (param.equals("san-jose")) {
			return "SJ dojo is the headquarters";
		}
		else {
		return param;
		}
    }
	
	
	
//	
//	@RequestMapping("/{berkeley}-dojo")
//	public String showLesson1(@PathVariable("berkeley") String berkeley){
//    	return "The " + berkeley + " Dojo is located in Emeryville.";
//    }
//	
////	@RequestMapping("/{berkeley}-{dojo}")
////	public String showLesson2(@PathVariable("berkeley") String berkeley, @PathVariable("dojo") String dojo){
////    	return "The " + berkeley.Uppercase() + " " + dojo + "is located in Emeryville.";
////    }
//	
//	@RequestMapping("/{san-jose}")
//	public String showLesson3(@PathVariable("san-jose") String san-jose){
//    	return "The  SJ Dojo is located in Emeryville.";
//    }
}
