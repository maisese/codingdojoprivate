INSERT INTO `books-schema`.`books` (`id`, `created_at`, `description`, `language`, `number_of_pages`, `title`, `updated_at`) VALUES ('1', '2019-02-08 19:44:31', 'great book', 'english', '1000', 'The Art of not giving a F*', '2019-02-08 19:44:31');

UPDATE `books-schema`.`books` SET `number_of_pages` = '150' WHERE (`id` = '1');