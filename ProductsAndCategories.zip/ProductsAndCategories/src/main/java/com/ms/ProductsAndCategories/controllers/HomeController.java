package com.ms.ProductsAndCategories.controllers;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.ms.ProductsAndCategories.models.Category;
import com.ms.ProductsAndCategories.models.CategoryProduct;
import com.ms.ProductsAndCategories.models.Product;
import com.ms.ProductsAndCategories.services.InventoryService;


@Controller
public class HomeController {
	
	@Autowired 
	public InventoryService iS;
	
	@GetMapping("/products/new")
	public String newProduct(@ModelAttribute("prodObj") Product product) {
		return "/products/new.jsp";
	}
	
	@PostMapping("/newProduct")
	//dojo creates the instance, and result is what is stored
		public String createProduct(@Valid @ModelAttribute("prodObj") Product product, BindingResult results) {
		if (results.hasErrors()) {
			return "products/new.jsp";
		}
		else {
			iS.createProd(product);
			Long id = product.getId();
			return "redirect:/products/"+ id;
		}
	}
	
	@GetMapping("/products/{id}")
	public String renderProduct(Model model, @PathVariable("id") Long id, @ModelAttribute("middleTableOBJ") CategoryProduct cP) {
		Product showproduct = iS.getProd(id);
		model.addAttribute("product", showproduct);
		
		//Will show list of categories
		List<Category> allCategories= iS.getAllCategories();
		model.addAttribute("showCategory", allCategories);
		return "products/show.jsp";
	}
	

	@PostMapping("/addCategory") 
	public String createCategory(@Valid @ModelAttribute("middleTableOBJ") CategoryProduct cP, BindingResult results) { 
		if (results.hasErrors()) { 
			return "products/show.jsp"; 
			} else { 
			iS.createCat(cP); 
			Long id = cP.getProduct().getId(); 
			return "redirect:/products/"+ id; 
			} 
	}
	
	
	@GetMapping("/categories/{id}")
	public String renderCategory(Model model, @PathVariable("id") Long id, @ModelAttribute("middleTableOBJ") CategoryProduct cP) {
		Category showcategory = iS.getCategory(id);
		model.addAttribute("category", showcategory);
		
		//Will show list of categories
		List<Product> allProducts= iS.getAllProducts();
		model.addAttribute("products", allProducts);
		return "categories/catshow.jsp";
	}
	
	@PostMapping("/addProduct") 
	public String addProducts(@Valid @ModelAttribute("middleTableOBJ") CategoryProduct cP, BindingResult results) { 
		if (results.hasErrors()) { 
			return "categories/catshow.jsp"; 
			} else { 
			iS.addProducts(cP); 
			Long id = cP.getCategory().getId(); 
			return "redirect:/categories/"+ id; 
			} 
	}


}
