package com.ms.ProductsAndCategories.repositories;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.ms.ProductsAndCategories.models.CategoryProduct;

@Repository	
public interface CategoryProductRepository extends CrudRepository <CategoryProduct, Long>{

}
