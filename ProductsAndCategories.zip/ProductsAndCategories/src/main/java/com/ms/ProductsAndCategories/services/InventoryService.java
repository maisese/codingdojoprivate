package com.ms.ProductsAndCategories.services;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ms.ProductsAndCategories.models.Category;
import com.ms.ProductsAndCategories.models.CategoryProduct;
import com.ms.ProductsAndCategories.models.Product;
import com.ms.ProductsAndCategories.repositories.CategoryProductRepository;
import com.ms.ProductsAndCategories.repositories.CategoryRepository;
import com.ms.ProductsAndCategories.repositories.ProductRepository;


@Service
public class InventoryService {

	@Autowired ProductRepository pR;
	
	@Autowired CategoryRepository cR;
	
	@Autowired CategoryProductRepository cPr;
	
	public void createProd(@Valid Product prod) {
		pR.save(prod);		
	}

	public Product getProd(Long id) {
		Optional <Product> getProdInfo = pR.findById(id);
		if (getProdInfo.isPresent()) {
		Product prodInfo =  getProdInfo.get();
		return prodInfo;
		}
		else {
			return null;
		}
	}

	public List<Category> getAllCategories() {
		return cR.findAll();
	}

	public void createCat(@Valid CategoryProduct cP) {
		cPr.save(cP);
		
	}

	public Category getCategory(Long id) {
		Optional <Category> getCatInfo = cR.findById(id);
		if (getCatInfo.isPresent()) {
		Category CatInfo = getCatInfo.get();
		return CatInfo;
		}
		else {
			return null;
		}
	}

	public List<Product> getAllProducts() {
		return pR.findAll();
	}

	public void addProducts(@Valid CategoryProduct cP) {
		cPr.save(cP);
	}
	
	
}
