package com.ms.ProductsAndCategories.repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.ms.ProductsAndCategories.models.Product;

public interface ProductRepository extends CrudRepository <Product, Long>{

	List<Product> findAll();
}
