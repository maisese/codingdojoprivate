package com.ms.XLoginandRegistration.Controllers;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.ms.XLoginandRegistration.Models.User;
import com.ms.XLoginandRegistration.service.UserService;

@Controller
public class UsersController {

	@Autowired
	public UserService uS;

	@RequestMapping("/")
	public String index() {
		return "index.jsp";
	}
	
	@RequestMapping("/registration")
	public String registerForm(@ModelAttribute("user") User user) {
		return "registrationPage.jsp";
	}

	@RequestMapping("/login")
	public String login() {
		return "loginPage.jsp";
	}

	@PostMapping("/registration")
    public String registerUser(@Valid @ModelAttribute("user") User user, BindingResult result, HttpSession session) {
       	if (result.hasErrors()) {
       		System.out.println("check out these results "+ result);
			return "registrationPage.jsp";
       	}
       	else {
       		User newUser = uS.registerUser(user);
       		System.out.println(newUser.getId());
       		session.setAttribute("userId", newUser.getId());
			return "redirect:/home";
		}
	}

    
    @PostMapping("/login")
    public String loginUser(@RequestParam("email") String email, @RequestParam("password") String password, Model model, HttpSession session) {
        Boolean isUserAuthenticated = uS.authenticateUser(email, password);
        if(isUserAuthenticated) {
        	User u = uS.findByEmail(email);
        	session.setAttribute("userId", u.getId());
        	return "redirect:/home";        	
        }
        else {
        	String error = "Invalid login.";
        	model.addAttribute("error", error);
        	return "loginPage.jsp";
        }
    }
    
    @RequestMapping("/home")
    public String home(HttpSession session, Model model) {
        Long userId = (Long) session.getAttribute("userId");
        User u = uS.findUserById(userId);
        System.out.println("This is the user" + u.getId());
        model.addAttribute("user", u);
    	return "homePage.jsp";
    }
    
    
    @RequestMapping("/logout")
	public String logout(HttpSession session) {
    	session.invalidate();
    	return "redirect:/";
	}
}
