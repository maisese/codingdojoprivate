package com.ms.dojosurvey.controllers;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class IndexController {

	@RequestMapping("/")
	public String index() {
		return "index.jsp";
	}

	@RequestMapping(value = "/submit", method = RequestMethod.POST)
	public String survey(@RequestParam(value = "name") String name,
			@RequestParam(value = "dojolocation") String dojolocation,
			@RequestParam(value = "favoritelan") String favoritelan, @RequestParam(value = "comment") String comment,
			HttpSession session) {
		session.setAttribute("name", name);
		session.setAttribute("dojolocation", dojolocation);
		session.setAttribute("favoritelan", favoritelan);
		session.setAttribute("comment", comment);
		return "redirect:/results";
	}
	
	@RequestMapping("/results")
	public String results(HttpSession session) {
		session.getAttribute("name");
		session.getAttribute("dojolocation");
		session.getAttribute("favoritelan");
		session.getAttribute("comment");
		return "results.jsp";
	}



}
