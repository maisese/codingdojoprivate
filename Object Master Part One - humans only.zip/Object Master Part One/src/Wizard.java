
public class Wizard extends Human{
	
	public Wizard(){
		this.health = 50;
		this.intelligence = 8;
	}
	
	public int heal(Object Human) {
		Human.health = this.intelligence;
	}
	
	public int fireball(Object Human) {
		Human.health = Human.health - (this.intelligence *3);
	}
	
}
