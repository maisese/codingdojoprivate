
public class Samurai extends Human{
	
	private static int counter;
	
	public Samurai() {
		this.health = 200;
		counter++;
	}
	
	pubic int deathBlow(Object Human) {
		Human.health = 0;
		this.health = this.health/2;
		}
	
	public int meditate() {
		this.health = (this.health *1.5);
	}
	
	public int howMany() {
		return counter;
	}

}


