
public class Ninja extends Human{
	
	public Ninja() {
		this.stealth = 10;
	}
	
	public int steal(Object Human) {
		this.stealth += Human.stealth;
	}
	
	public int runAway() {
		this.health -= 10;
	}

}
