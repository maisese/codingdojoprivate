package com.codingodojo.displaydate;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;



@Controller

public class Home{
	
	@RequestMapping("/") 
		public String index() {
	        return "index.jsp";
		}
	
	@RequestMapping("/date") 
	public String date(Model model ) {
		Date newDate = new java.util.Date();
		// ' in the simple date format, to insert word.
		SimpleDateFormat dateFormat = new SimpleDateFormat("EEEEE, 'the' dd 'of' MMMM yyyy");
		model.addAttribute("getdate", dateFormat.format(newDate));
		return "date.jsp";
	}
	
	@RequestMapping("/time") 
	public String time(Model model) {
		java.util.Date Time = new java.util.Date();
		SimpleDateFormat dateFormat = new SimpleDateFormat("hh:mm a");
		model.addAttribute("getTime", dateFormat.format(Time));
		return "time.jsp";
	}
}
	

