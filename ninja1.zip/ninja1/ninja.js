 function Ninja(name) {
    var self = this;
    var privateVariable = "This variable is private";
    var privateMethod = function() {
        this.speed = 3;
        this.strength = 3;
        console.log("this is a private method for " + self.name);
        console.log(self);
    };
    this.name = name;
    this.health = 100;
    this.greet = function() {
        console.log("Hello my name is " + this.name + " and my health is " + this.health + ".");
        // we can access our attributes within the constructor!
        console.log("Also my privateVariable says: " + privateVariable);
        // we can access our methods within the constructor!
        privateMethod();
    };
    this.sayName = function() {
        console.log("My name is " + this.name + ".");
    };
    this.showStats = function() {
        console.log("Name: " + this.name + ", " + "Health: " + this.health + ", " + "Speed: " + this.speed + ", " + "Strength: " + this.strength+ ".");
    };
    this.drinksake = function() {
        this.health += 10; 
        console.log("Name: " + this.name + "," + "Health: " + this.health +".");
    };
}

