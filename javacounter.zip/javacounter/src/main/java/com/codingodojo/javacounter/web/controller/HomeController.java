package com.codingodojo.javacounter.web.controller;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HomeController{
	
	@RequestMapping("/") 
		public String index(HttpSession session) {
		Integer counter = (Integer) session.getAttribute("counter");
		System.out.println(counter);
		if (counter != null) {
			counter++;
			System.out.println("test2");
		} else {
			session.setAttribute("counter", 0);
			System.out.println("Test1");
			System.out.println(session.getAttribute("counter"));
		}
		if(counter!=null) {
			session.setAttribute("counter", counter);
			
		}
		return "index.jsp";
	}

	@RequestMapping("/counter")
	public String counter(HttpSession session, Model model) {
		//we inject our model in object in our paramenters, 
		String showcount = Integer.toString((int) (session.getAttribute("counter")) );
		model.addAttribute("showcount", showcount);
 					        //referencing variable  //no quotes, just the value, the vale tied to it.
		return "counter.jsp";
	}
	
	@RequestMapping("/countby2")
	public String countby2(HttpSession session) {
		Integer counter = (Integer) session.getAttribute("counter");
		System.out.println(counter);
		if (counter != null) {
			counter = counter +2;
			System.out.println("test2");
		} else {
			session.setAttribute("counter", 0);
			System.out.println("Test1");
			System.out.println(session.getAttribute("counter"));
		}
		if(counter!=null) {
			session.setAttribute("counter", counter);
			
		}
		return "countby2.jsp";
	}
	
	@RequestMapping("/clear")
	public String clear(HttpSession session) {
		Integer counter = (Integer) session.getAttribute("counter");
		System.out.println(counter);
			session.setAttribute("counter", 0);
			System.out.println("Test1");
			System.out.println(session.getAttribute("counter"));
			return "counter.jsp";
		}
	
//	@RequestMapping("/counter")
//	public String counter() {
//		return "counter.jsp";
//	}
		
}
