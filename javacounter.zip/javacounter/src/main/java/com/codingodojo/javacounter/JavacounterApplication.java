package com.codingodojo.javacounter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication

public class JavacounterApplication {

	public static void main(String[] args) {
		SpringApplication.run(JavacounterApplication.class, args);
		

	}
}
