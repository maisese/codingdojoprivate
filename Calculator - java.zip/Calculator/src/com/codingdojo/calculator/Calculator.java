package com.codingdojo.calculator;

public class Calculator {
	//Variables 
	private double OperandOne;
	private String Operation;
	private double OperandTwo;
	private double result;
	
	//Constructor
	public Calculator(double operandOne, String operation, double operandTwo) {
		OperandOne = operandOne;
		Operation = operation;
		OperandTwo = operandTwo;
	}
	
	//Empty Consructor 
	public Calculator() {
		
	}
	
	//Getters and Setters
	public String getOperation() {
		return Operation;
	}

	public void setOperation(String operation) {
		Operation = operation;
	}

	public double getOperandTwo() {
		return OperandTwo;
	}

	public void setOperandTwo(double operandTwo) {
		OperandTwo = operandTwo;
	}

	public double getOperandOne() {
		return OperandOne;
	}

	public int setOperandOne(double number) {
		OperandOne = number;
		return (int) OperandOne;
	}
	
	//Methods
	
	public double performOperation() {
		if (Operation == "+") {
			result = OperandOne + OperandTwo;
		}
		if (Operation == "-") {
			result = OperandOne - OperandTwo;
		}
		if (Operation == "/") {
			result = OperandOne / OperandTwo;
		}
		if (Operation == "*") {
			result = OperandOne * OperandTwo;
		}
		return result;
	}
	
	public double getResults() {
		System.out.println(result);
		return result;
	}
	
	

	
	
	


	
	
}
