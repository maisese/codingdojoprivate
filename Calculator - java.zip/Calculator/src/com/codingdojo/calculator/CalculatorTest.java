package com.codingdojo.calculator;

public class CalculatorTest {

	public static void main(String[] args) {
		Calculator maitest = new Calculator();
		
		maitest.setOperandOne(10.5);
		maitest.setOperation("*");
		maitest.setOperandTwo(2.5);
		maitest.performOperation();
		maitest.getResults();
		

	}

}
