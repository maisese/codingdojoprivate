package com.ms.mvc.controllers;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ms.mvc.models.Book;
import com.ms.mvc.services.BookService;



@RestController

public class BooksApi {
    private final BookService bookService;
    
    
    public BooksApi(BookService bookService){
        this.bookService = bookService;
    }
    
//    @GetMapping("/books")
//    public List<Book> getBooks() {
//    	return bookService.allBooks();
//    }
    
    // other methods removed for brevity
    @RequestMapping(value="/api/books/{id}", method=RequestMethod.PUT)
    public Book update(@PathVariable("id") Long id, @RequestParam(value="title") String title, @RequestParam(value="description") String desc, @RequestParam(value="language") String lang, @RequestParam(value="pages") Integer numOfPages) {
        Book book = bookService.updateBook(id, title, desc, lang, numOfPages);
        return book;
    }
    
    @RequestMapping(value="/api/books/{id}", method=RequestMethod.DELETE)
    public void destroy(@PathVariable("id") Long id) {
        bookService.deleteBook(id);
    }
}

//Your task is to write the services methods that will correctly update and delete a book. 
//To update a book, you will have to use the setter methods from the domain model and then call the save method. 
//As you can see, save is used for both creating and updating. To delete a book, you will have to use the deleteById method. 
//Below, I have linked to the CrudRepository documentation.
