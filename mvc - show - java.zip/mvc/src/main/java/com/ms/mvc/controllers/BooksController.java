package com.ms.mvc.controllers;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ms.mvc.models.Book;
import com.ms.mvc.services.BookService;

@Controller
public class BooksController {
    private final BookService bookService;
    
    public BooksController(BookService bookService) {
        this.bookService = bookService;
    }
    
    @RequestMapping("/books/new")
    public String newBook(@ModelAttribute("book") Book book) {
        return "/books/new.jsp";
    }
    
    @RequestMapping("/books")
    public String index(Model model) {
        List<Book> books = bookService.allBooks();
        model.addAttribute("books", books);
        return "books/index.jsp";
    }
    
    @GetMapping("/books/{id}")
    public String findOneBook(@PathVariable("id") Long id, Model model) {
    	Book foundbook = bookService.findBook(id);
    	System.out.println("this in books/id" + foundbook);
    	//books is what you're passing in, not the foundbook.  Books is your key
        model.addAttribute("books", foundbook);
         return "/books/show.jsp";
    }
    
    
}