
public class BatTest {

	public static void main(String[] args) {
		Bat bubbles = new Bat();
		
		bubbles.printEnergy();
		bubbles.attackTown();
		bubbles.attackTown();
		bubbles.attackTown();
		bubbles.eatHumans();
		bubbles.eatHumans();
		bubbles.fly();
		bubbles.fly();
	
	}

}
