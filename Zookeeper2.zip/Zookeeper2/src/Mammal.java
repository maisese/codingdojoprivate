
public class Mammal {
	protected int energyLevel = 100;
    
	public int displayEnergy() {
        System.out.println(this.energyLevel);
        return this.energyLevel;
	
//	public void displayEnergy() {
//        System.out.println(this.energyLevel);
       
    }
    
    
}
