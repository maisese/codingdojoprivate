
public class GorillaTest {

	public static void main(String[] args) {
		Gorilla bubbles = new Gorilla();
		
//		bubbles.throwSomething();
//		bubbles.eatBananas();
//		bubbles.climb();
		
		bubbles.throwSomething();
		bubbles.throwSomething();
		bubbles.throwSomething();
		bubbles.eatBananas();
		bubbles.eatBananas();
		bubbles.climb();
		
		
		
		
		

	}

}
